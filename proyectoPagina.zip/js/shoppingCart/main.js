//Creo la clase Producto
class Producto {
    constructor(nombre, precio, id, cantidad, stock) {
        this.nombre = nombre;
        this.precio = parseFloat(precio);
        this.id = parseInt(id);
        this.cantidad = parseInt(cantidad);
        this.stock = parseInt(stock);
        this.vendido = false;
        this.valorTotal = this.precio * this.cantidad;
    }
    sumarIva() {
        this.precio = this.precio * 1.21;
    }

    updateStock() {
        this.stock = this.stock - this.cantidad;
        return this.stock;
    }
    getCantidad() {
        return cantidad;
    }
}

//Declaro el array almacen que contiene objetos de tipo Producto
const almacen = [];
carrito = [];
almacen.push(new Producto("cable adaptador cpu fuente", 600, 1, 0, 20));
almacen.push(new Producto("riser adaptador 1x a 16x", 1200, 2, 0, 20));
almacen.push(new Producto("riser adaptador multiple", 6200, 3, 0, 20));

//Agrego items al carrito de compras desde el listado de productos en almacen
// do {

//     choice = parseInt(prompt("Bienvenido a la tienda Bitba,seleccione el codigo del producto que desee comprar o ingrese 0 para salir \n codigo #1: 1\n codigo #2: 2 \n codigo #3: 3"));
//     if (choice != 0) {
//         carrito.push(almacen.filter(Producto => Producto.id == choice));
//     }

// } while (choice != 0);

console.log(almacen);
console.log(almacen[0]);
console.log(carrito);

//Almaceno en el storage el contenido del carrito
localStorage.setItem('productos', JSON.stringify(carrito));
console.log(window.localStorage.length);

let form1 = document.getElementById("form1");
form1.onclick = () => console.log("oninput");

//Desarrollo la escucha de evento al presionar click en enviar
//sobre el primer producto de la lista en la tienda

const sendQuantityBtn1A = document.getElementById('quantityBtn1A');
const sendQuantityBtn1B = document.getElementById('quantityBtn1B');
let cantidad = 0;
sendQuantityBtn1A.oninput = function() {
    cantidad = sendQuantityBtn1A.value;
    console.log(cantidad);
}
sendQuantityBtn1B.oninput = function() {
    cantidad = sendQuantityBtn1B.value;
    console.log(cantidad);
}

const sendButton1 = document.getElementById("sendBtn1");
sendButton1.addEventListener('click', addToCart);

//Agrego la seleccion del producto al carrito y actualizo la burbuja de
//notificacion en el carrito con la cantidad de items
function addToCart() {

    if (cantidad != 0) {
        almacen[0].cantidad = cantidad;
        carrito.push(almacen.filter(Producto => Producto.id == 1));

        console.log(carrito);
        console.log(carrito[0]);

        //Obtengo el numero de productos en el carrito
        const itemsNumber = carrito.length;
        console.log(itemsNumber);

        //Prueba recorro el array para obtener la cantidad 
        //en cada producto del carrito
        const primero = carrito[0];
        console.log(primero.getCantidad());
        let totalItems = 0;
        for (const item of carrito) {
            console.log(item.cantidad);
            totalItems = totalItems + item.cantidad;
            console.log(totalItems);
        }
        console.log(totalItems);

        //Creo el texto con el valor numerico de items en el carrito
        newValue = document.createTextNode(itemsNumber);


        //Obtengo los nodos de html correspondientes al carrito
        let numItems = [];
        numItems[0] = document.getElementById("lblCartCountMobile");
        numItems[1] = document.getElementById("lblCartCountDesktop");
        console.log(numItems[0]);
        console.log(numItems[1]);
        numItems[0].appendChild(newValue);
        numItems[1].appendChild(newValue);


        //Muestro burbuja con nro de items en carrito
        if (carrito.length != 0) {
            document.getElementById('lblCartCountMobile').style.display = "block";
            document.getElementById('lblCartCountDesktop').style.display = "block";
        }

    }
}