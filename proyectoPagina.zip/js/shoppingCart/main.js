//Creo la clase Producto

class Producto {
    constructor(nombre, precio, id, cantidad, stock) {
        this.nombre = nombre;
        this.precio = parseFloat(precio);
        this.id = parseInt(id);
        this.cantidad = parseInt(cantidad);
        this.stock = parseInt(stock);
        this.vendido = false;
        this.valorTotal = this.precio * this.cantidad;
    }
    sumarIva() {
        this.precio = this.precio * 1.21;
    }

    updateStock() {
        this.stock = this.stock - this.cantidad;
        return this.stock;
    }
    getCantidad() {
        return cantidad;
    }
}

//Declaro el array almacen que contiene objetos de tipo Producto

const almacen = [];
carrito = [];
almacen.push(new Producto("cable adaptador cpu fuente", 600.99, 1, 0, 20));
almacen.push(new Producto("riser adaptador 1x a 16x", 1200.99, 2, 0, 20));
almacen.push(new Producto("riser adaptador multiple", 6200.99, 3, 0, 20));
almacen.push(new Producto("breakout board 12 salidas", 2200.99, 4, 0, 20));
almacen.push(new Producto("fuente servidor 1400w", 40200, 5, 0, 20));
almacen.push(new Producto("estructura de rig para 5 gpus", 11200, 6, 0, 20));
almacen.push(new Producto("rig de mineria 7 gpus", 1120000, 7, 0, 20));
almacen.push(new Producto("rig de mineria 7 gpus", 1304000, 8, 0, 20));
almacen.push(new Producto("rig de mineria 7 gpus", 1650000, 9, 0, 20));

//Almaceno en el storage el contenido del alamacen

localStorage.setItem('productosAlmacen', JSON.stringify(almacen));
console.log(window.localStorage.length);

//Compruebo por consola contenidos en arrays almacen y carrito

console.log(almacen);
console.log(almacen[0]);
console.log(carrito);

//Capturo los eventos en cada boton "Agregar al carrito"
//y en el numero seleccionado de cantidad de items

const sendButton1 = document.getElementById("sendBtn1");
const quantity1 = document.getElementById("quantityBtn1");
console.log(quantity1.value);
sendButton1.addEventListener('click', addToBuyCart(1, quantity1.value));
console.log(carrito);

const sendButton2 = document.getElementById("sendBtn2");
const quantity2 = document.getElementById("quantityBtn2");
console.log(quantity2.value);
sendButton1.addEventListener('click', addToBuyCart(2, quantity2.value));
console.log(carrito);

const sendButton3 = document.getElementById("sendBtn3");
const quantity3 = document.getElementById("quantityBtn3");
console.log(quantity3.value);
sendButton3.addEventListener('click', addToBuyCart(3, quantity3.value));
console.log(carrito);

const sendButton4 = document.getElementById("sendBtn4");
const quantity4 = document.getElementById("quantityBtn4");
console.log(quantity4.value);
sendButton4.addEventListener('click', addToBuyCart(4, quantity4.value));
console.log(carrito);

const sendButton5 = document.getElementById("sendBtn5");
const quantity5 = document.getElementById("quantityBtn5");
console.log(quantity4.value);
sendButton5.addEventListener('click', addToBuyCart(5, quantity5.value));
console.log(carrito);

const sendButton6 = document.getElementById("sendBtn6");
const quantity6 = document.getElementById("quantityBtn6");
console.log(quantity6.value);
sendButton6.addEventListener('click', addToBuyCart(6, quantity6.value));
console.log(carrito);

const sendButton7 = document.getElementById("sendBtn7");
const quantity7 = document.getElementById("quantityBtn7");
console.log(quantity7.value);
sendButton7.addEventListener('click', addToBuyCart(7, quantity7.value));
console.log(carrito);

const sendButton8 = document.getElementById("sendBtn8");
const quantity8 = document.getElementById("quantityBtn8");
console.log(quantity4.value);
sendButton8.addEventListener('click', addToBuyCart(8, quantity8.value));
console.log(carrito);

const sendButton9 = document.getElementById("sendBtn9");
const quantity9 = document.getElementById("quantityBtn9");
console.log(quantity9.value);
sendButton9.addEventListener('click', addToBuyCart(9, quantity9.value));
console.log(carrito);

//Creo la funcion agregar al carrito
//si id no esta incluido al array se agrega en la ultima posicion
//si el id ya se eligio actualizo la cantidad del item en el array

function addToBuyCart(id, cant) {

    if (carrito.filter(Producto => Producto.id == id) == false) {
        carrito.push(almacen.filter(Producto => Producto.id == id));
        console.log(carrito[0]);
        carrito[carrito.length - 1].cantidad = cant;
    } else {
        for (var i = 0; i < carrito.length; i++) {
            if (carrito[i].id = id) {
                carrito[i].cantidad = carrito[i].cantidad + cant;
            }
        }
    }
    console.log(carrito);
}

console.log(totalQuantity(carrito));

//Recorro el array carrito para calcular la cantidad de items elegidos

let totalItems = 0;

function totalQuantity(carrito) {
    let totalItems = 0;
    for (const item of carrito) {
        totalItems = totalItems + parseInt(item.cantidad);
    }
    console.log(totalItems);
    return (totalItems);
}

//Agrego al badge la cantidad total de items
let cartTotalDesktop = document.getElementById('lblCartCountDesktop');
let cartTotalMobile = document.getElementById('lblCartCountMobile');
newValue = document.createTextNode(totalQuantity(carrito));
console.log(newValue);
cartTotalDesktop.appendChild(newValue);
cartTotalMobile.appendChild(newValue);

if (carrito.length != 0) {
    document.getElementById('lblCartCountMobile').style.display = "block";
    document.getElementById('lblCartCountDesktop').style.display = "block";
}


// //Agrego la seleccion del producto al carrito y actualizo la burbuja de
// //notificacion en el carrito con la cantidad de items
// function addToCart() {
//     const quantites = document.getElementsByClassName('quantityBtn1B');
//     // const prices = document.getElementsByClassName('price');
//     let carritoTotal = document.getElementById('cartTotalQ');
//     let totalQ = 0;
//     // let totalP=0
//     for (let i = 0; i < quantites.length; i++) {
//         totalQ += parseInt(quantites[i].value)
//             // totalP += Number(prices[i].value)*parseInt(quantites[i].value)
//     }
//     console.log(totalQ);
//     newValue = document.createTextNode(totalQ);

//     carritoTotal.appendChild(newValue);
//     // carritoTotal.innerHTML = totalQ;
//     if (cantidad != 0) {
//         almacen[0].cantidad = cantidad;
//         carrito.push(almacen.filter(Producto => Producto.id == 1));
//         console.log(carrito);
//         //     console.log(carrito[0]);
//         //     //Obtengo el numero de productos en el carrito
//         //     const itemsNumber = carrito.length;
//         //     console.log(itemsNumber);
//         //     //Prueba recorro el array para obtener la cantidad
//         //     //en cada producto del carrito
//         //     const primero = carrito[0];
//         //     // console.log(primero.getCantidad());
//         //     let totalItems = 0;
//         //     for (const item of carrito) {
//         //         console.log(item.cantidad);
//         //         totalItems = totalItems + item.cantidad;
//         //         console.log(totalItems);
//         //     }
//         //     console.log(totalItems);
//         //     //Creo el texto con el valor numerico de items en el carrito
//         //     newValue = document.createTextNode(itemsNumber);
//         //     //Obtengo los nodos de html correspondientes al carrito
//         //     let numItems = [];
//         //     numItems[0] = document.getElementById("lblCartCountMobile");
//         //     numItems[1] = document.getElementById("lblCartCountDesktop");
//         //     console.log(numItems[0]);
//         //     console.log(numItems[1]);
//         //     numItems[0].appendChild(newValue);
//         //     numItems[1].appendChild(newValue);
//         //     //Muestro burbuja con nro de items en carrito
//         //     if (carrito.length != 0) {
//         //         document.getElementById('lblCartCountMobile').style.display = "block";
//         //         document.getElementById('lblCartCountDesktop').style.display = "block";
//         //     }
//         // }
//     }

// }
//Almaceno en el storage el contenido del carrito
localStorage.setItem('productosCarrito', JSON.stringify(carrito));
console.log(window.localStorage.length);